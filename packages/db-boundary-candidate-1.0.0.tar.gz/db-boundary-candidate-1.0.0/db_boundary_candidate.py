VALUE = "benign candidate baseline"
